export type QuestionType = 'single' | 'multiple';

export const QuestionTypes = ['single', 'multiple'] as const;
