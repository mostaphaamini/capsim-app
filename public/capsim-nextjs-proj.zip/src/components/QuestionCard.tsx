'use client';

import React from 'react';
import { Question, Answer } from '../types/types';

interface QuestionCardProps {
  question: Question;
  selected: number[];
  onChange: (answerId: number, checked: boolean) => void;
}

export default function QuestionCard({ question, selected, onChange }: QuestionCardProps) {
  const isSingle = question.type === 'single';

  const handleChange = (answerId: number, checked: boolean) => {
    if (isSingle) {
      onChange(answerId, true); // single choice only one
    } else {
      onChange(answerId, checked);
    }
  };

  return (
    <div className="border p-4 rounded mb-6">
      <h3 className="font-semibold mb-3">{question.text}</h3>
      <div>
        {question.answers.map((answer) => (
          <label key={answer.id} className="flex items-center mb-2 cursor-pointer">
            <input
              type={isSingle ? 'radio' : 'checkbox'}
              name={`question-${question.id}`}
              value={answer.id}
              checked={selected.includes(answer.id)}
              onChange={(e) => handleChange(answer.id, e.target.checked)}
              className="mr-2"
            />
            {answer.text}
          </label>
        ))}
      </div>
    </div>
  );
}
