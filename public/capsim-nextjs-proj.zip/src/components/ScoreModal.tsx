'use client';

import React from 'react';

interface ScoreModalProps {
  score: number | null;
  onClose: () => void;
}

export default function ScoreModal({ score, onClose }: ScoreModalProps) {
  if (score === null) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded shadow-lg w-80 text-center">
        <h2 className="text-xl font-bold mb-4">Your Score</h2>
        <p className="text-4xl font-extrabold mb-6">{score}%</p>
        <button
          onClick={onClose}
          className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
        >
          Close
        </button>
      </div>
    </div>
  );
}
