'use client';

import React, { useEffect, useState } from 'react';
import api from '../../lib/api';
import { ReportBucket } from '../../types/types';
import Chart from '../../components/Chart';

export default function ReportPage() {
  const [reportData, setReportData] = useState<ReportBucket[]>([]);

  useEffect(() => {
    api.get<ReportBucket[]>('/submissions/report').then((res) => {
      setReportData(res.data);
    });
  }, []);

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Score Report</h1>
      <Chart data={reportData} />
    </div>
  );
}
