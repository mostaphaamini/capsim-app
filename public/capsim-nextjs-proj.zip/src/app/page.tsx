'use client';

import React, { useEffect, useState } from 'react';
import api from '../lib/api';
import { Question, SubmissionPayload, SubmissionResult } from '../types/types';
import QuestionCard from '../components/QuestionCard';
import ScoreModal from '../components/ScoreModal';

export default function QuizPage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<number, number[]>>({});
  const [score, setScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get<Question[]>('/questions').then((res) => {
      setQuestions(res.data);
      // Initialize answers state
      const initial: Record<number, number[]> = {};
      res.data.forEach((q) => (initial[q.id] = []));
      setAnswers(initial);
    });
  }, []);

  const handleAnswerChange = (questionId: number, answerId: number, checked: boolean) => {
    setAnswers((prev) => {
      const current = prev[questionId] ?? [];
      const question = questions.find((q) => q.id === questionId);
      if (!question) return prev;

      if (question.type === 'single') {
        return { ...prev, [questionId]: [answerId] };
      } else {
        let updated = [...current];
        if (checked) {
          updated.push(answerId);
        } else {
          updated = updated.filter((id) => id !== answerId);
        }
        return { ...prev, [questionId]: updated };
      }
    });
  };

  const allAnswered = questions.every((q) => answers[q.id]?.length > 0);

  const handleSubmit = async () => {
    if (!allAnswered) {
      alert('Please answer all questions before submitting.');
      return;
    }
    setLoading(true);

    const payload: SubmissionPayload = {
      answers: questions.map((q) => ({
        questionId: q.id,
        selectedAnswerIds: answers[q.id],
      })),
    };

    try {
      const res = await api.post<SubmissionResult>('/submissions', payload);
      setScore(res.data.score);
    } catch (error) {
      alert('Error submitting quiz.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Capsim Quiz</h1>
      {questions.map((q) => (
        <QuestionCard
          key={q.id}
          question={q}
          selected={answers[q.id] ?? []}
          onChange={(answerId, checked) => handleAnswerChange(q.id, answerId, checked)}
        />
      ))}

      <button
        disabled={!allAnswered || loading}
        onClick={handleSubmit}
        className={`bg-blue-600 text-white py-2 px-6 rounded ${(!allAnswered || loading) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'}`}
      >
        {loading ? 'Submitting...' : 'Submit Quiz'}
      </button>

      <ScoreModal score={score} onClose={() => setScore(null)} />
    </div>
  );
}
