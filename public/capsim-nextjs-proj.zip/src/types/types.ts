export type QuestionType = 'single' | 'multiple';

export interface Answer {
  id: number;
  text: string;
  points: number;
}

export interface Question {
  id: number;
  text: string;
  type: QuestionType;
  answers: Answer[];
}

export interface SubmissionPayload {
  answers: {
    questionId: number;
    selectedAnswerIds: number[];
  }[];
}

export interface SubmissionResult {
  score: number;
  totalPoints: number;
  maxPoints: number;
}

export interface ReportBucket {
  range: string;
  count: number;
}
