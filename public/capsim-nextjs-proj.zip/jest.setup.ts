import '@testing-library/jest-dom';
import { server } from './mocks/server.mock'; 

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
