# Capsim Assessment Frontend

This is the frontend React app built with Next.js (App Router) and Tailwind CSS. It fetches quiz questions, displays the quiz UI, submits answers, and shows the report.

---

## Features

- Fetches 5 random quiz questions from backend API
- Supports single and multiple choice questions
- Displays submission results with score percentage
- Shows report page with bar chart of score distribution (using Recharts)
- Environment-based API URL configuration
- Fully tested with React Testing Library and MSW
- Styled with Tailwind CSS

---

## Tech Stack

- React 18+
- Next.js 13+ (App Router)
- Tailwind CSS
- Axios for API calls
- Recharts for charts
- Jest + React Testing Library + MSW for testing

---

## Setup

### 1. Install dependencies

```bash
cd frontend
npm install
```

### 2. Configure environment variables

Create `.env.local` in `frontend/`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8080
```

> This should point to your backend API URL

---

### 3. Run development server

```bash
npm run dev
```

Open `http://localhost:3000` in your browser

---

### 4. Build and export static files (optional)

If you want to build a static export for serving via backend or static host:

1. Add to `next.config.js`:

```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
};
module.exports = nextConfig;
```

2. Run:

```bash
npm run build
```

Static files will be generated in `out/`

---

## Testing

```bash
npm run test
```

---

## Project Structure

```
frontend/
├── app/
├── components/
├── lib/
├── types/
├── __tests__/
├── public/
├── .env.local
├── package.json
├── next.config.js
└── tsconfig.json
```

---

## Deployment

- Recommended platforms: Vercel, Netlify
- Set `NEXT_PUBLIC_API_URL` in your environment variables during deployment

---

## 👨‍💻 Author

Matthew C Mark  
📧 [matthew.c.mark.dev@gmail.com](mailto:matthew.c.mark.dev@gmail.com)  

> 💡 Feel free to customize this README with your own name, email, GitHub, and deployment URLs.
