import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import QuizPage from '@/app/page';
import React from 'react';

describe('Quiz Page', () => {
  it('renders quiz, selects answers, submits, and shows score', async () => {
    render(<QuizPage />);

    expect(await screen.findByText(/motivation/i)).toBeInTheDocument();

    const radio = screen.getByLabelText('Read a book');
    fireEvent.click(radio);

    const submit = screen.getByRole('button', { name: /submit quiz/i });
    fireEvent.click(submit);

    await waitFor(() => {
      expect(screen.getByText(/your score/i)).toBeInTheDocument();
      expect(screen.getByText('73%')).toBeInTheDocument();
    });
  });
});
