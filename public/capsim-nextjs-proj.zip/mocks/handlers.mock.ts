import { rest } from 'msw';
import { Question, ReportBucket } from '@/types/types';

export const handlers = [
  rest.get('http://localhost:8080/questions', (req, res, ctx) => {
    const questions: Question[] = [
      {
        id: 1,
        text: 'What’s the first thing you should do when you need motivation?',
        type: 'single',
        answers: [
          { id: 101, text: 'Read a book', points: 5 },
          { id: 102, text: 'Watch social media', points: 0 },
        ],
      },
    ];
    return res(ctx.status(200), ctx.json(questions));
  }),

  rest.post('http://localhost:8080/submissions', (req, res, ctx) => {
    return res(
      ctx.status(201),
      ctx.json({ score: 73, totalPoints: 8, maxPoints: 11 })
    );
  }),

  rest.get('http://localhost:8080/submissions/report', (req, res, ctx) => {
    const buckets: ReportBucket[] = [
      { range: '0-9%', count: 0 },
      { range: '70-79%', count: 1 },
    ];
    return res(ctx.status(200), ctx.json(buckets));
  }),
];
